package com.geektech;

public class Weapon {
    private String pistol;


}
