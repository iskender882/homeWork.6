package com.geektech;

public class Main {
    public static void main(String[] args) {
        boss Goro = new boss("Goro", 390, "pistol");
    }

}

